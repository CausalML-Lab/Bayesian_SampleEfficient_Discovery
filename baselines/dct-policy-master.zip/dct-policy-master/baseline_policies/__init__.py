from .coloring_policy import *
from .greedy_entropy_policy import *
from .greedy_minmax_policy import *
from .max_degree_policy import *
from .opt_single import *
from .random_policy import *
